/*******************************/
/*  Winfree simulation library */
/*******************************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<gsl/gsl_rng.h>
#include<gsl/gsl_randist.h>
#include<ctype.h>
#include<limits.h>

/* Additional libraries (custom libraries) */
#include "utils.h"
#include "winfree.h"

